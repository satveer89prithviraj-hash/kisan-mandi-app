# किसान मंडी — Functional Android v1

यह version पुराने placeholder skeleton को एक usable Hindi-first app flow में बदलता है।
मुख्य modules: voice input, भाव, बेचने की जगह, खरीदार, मेरा माल, हिसाब और AI किसान साथी।

महत्वपूर्ण:
- Demo/local prices को सरकारी live prices न मानें।
- Production में verified government mandi data/API और verified buyer backend जोड़ना आवश्यक है।
- Secrets/API keys source code में नहीं रखें।
- Release build versionCode 21 / versionName 1.1.0 है।
