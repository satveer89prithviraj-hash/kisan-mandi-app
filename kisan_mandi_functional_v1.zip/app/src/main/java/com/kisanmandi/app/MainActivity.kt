package com.kisanmandi.app

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var commodityInput: EditText
    private lateinit var statusText: TextView

    private val voiceRequest = 1001

    private data class Price(val market: String, val commodity: String, val min: Int, val max: Int, val modal: Int)
    private val demoPrices = listOf(
        Price("स्थानीय मंडी", "गेहूँ", 2200, 2450, 2325),
        Price("स्थानीय मंडी", "धान", 1900, 2350, 2150),
        Price("स्थानीय मंडी", "आलू", 900, 1450, 1180),
        Price("स्थानीय मंडी", "प्याज", 1200, 2200, 1700)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        commodityInput = findViewById(R.id.commodityInput)
        statusText = findViewById(R.id.statusText)

        findViewById<Button>(R.id.voiceButton).setOnClickListener { startVoice() }
        findViewById<Button>(R.id.priceButton).setOnClickListener { showPrices() }
        findViewById<Button>(R.id.sellButton).setOnClickListener { showSellOptions() }
        findViewById<Button>(R.id.buyerButton).setOnClickListener { showBuyers() }
        findViewById<Button>(R.id.myGoodsButton).setOnClickListener { showMyGoods() }
        findViewById<Button>(R.id.calculatorButton).setOnClickListener { showCalculator() }
        findViewById<Button>(R.id.aiButton).setOnClickListener { showAi() }
    }

    private fun crop(): String = commodityInput.text.toString().trim().ifEmpty { "गेहूँ" }

    private fun startVoice() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), voiceRequest)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "फसल या अपना सवाल बोलिए")
        }
        try { startActivityForResult(intent, voiceRequest) }
        catch (_: Exception) { statusText.text = "इस फोन में voice input उपलब्ध नहीं है।" }
    }

    @Deprecated("Android callback API retained for minSdk compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!result.isNullOrBlank()) {
                commodityInput.setText(result)
                statusText.text = "आपने कहा: $result"
            }
        }
    }

    private fun showPrices() {
        val c = crop()
        val matches = demoPrices.filter { it.commodity.equals(c, true) || c.contains(it.commodity) || it.commodity.contains(c) }
        val text = if (matches.isEmpty()) {
            "फसल: $c\n\nइस समय इस फसल का स्थानीय नमूना रिकॉर्ड उपलब्ध नहीं है।\n\nमहत्वपूर्ण: यह build demo/local data दिखा रहा है; production में केवल सत्यापित सरकारी मंडी स्रोत से भाव दिखाया जाएगा।"
        } else {
            matches.joinToString("\n\n") {
                "${it.market}\n${it.commodity}: ₹${it.min}–₹${it.max}/क्विंटल\nModal: ₹${it.modal}/क्विंटल"
            } + "\n\n⚠️ यह प्रारंभिक local demo data है; इसे सरकारी live rate न मानें।"
        }
        dialog("आज का भाव", text)
    }

    private fun showSellOptions() {
        dialog("कहाँ बेचें?", "1. अपनी नजदीकी APMC/मंडी चुनें।\n2. फसल और मात्रा दर्ज करें।\n3. खरीदार के verified offer की तुलना करें।\n\nअगले backend चरण में वास्तविक location और mandi-data जोड़ने के लिए यह screen तैयार है।")
    }

    private fun showBuyers() {
        dialog("भरोसेमंद खरीदार", "अभी कोई खरीदार सत्यापित करके सूचीबद्ध नहीं किया गया है।\n\nProduction में buyer को KYC/verification status के साथ दिखाया जाएगा। बिना verification के किसी खरीदार को 'भरोसेमंद' नहीं कहा जाएगा।")
    }

    private fun showMyGoods() {
        dialog("मेरा माल", "यहाँ किसान अपनी फसल, मात्रा, अपेक्षित भाव और बिक्री की स्थिति रख सकेगा।\n\nइस v1 build में local entry flow का ढाँचा तैयार है; server sync अगले backend चरण में जोड़ा जाएगा।")
    }

    private fun showCalculator() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 5, 30, 5)
        }
        val qty = EditText(this).apply { hint = "मात्रा (क्विंटल)"; inputType = 2 }
        val rate = EditText(this).apply { hint = "भाव ₹/क्विंटल"; inputType = 2 }
        val cost = EditText(this).apply { hint = "कुल खर्च ₹"; inputType = 2 }
        val result = TextView(this).apply { textSize = 18f; setPadding(0, 18, 0, 0) }
        box.addView(qty); box.addView(rate); box.addView(cost); box.addView(result)

        AlertDialog.Builder(this).setTitle("आज का हिसाब")
            .setView(box)
            .setPositiveButton("गणना") { _, _ ->
                val q = qty.text.toString().toDoubleOrNull() ?: 0.0
                val r = rate.text.toString().toDoubleOrNull() ?: 0.0
                val c = cost.text.toString().toDoubleOrNull() ?: 0.0
                val gross = q * r
                result.text = "कुल बिक्री: ₹${"%.2f".format(Locale.US, gross)}\nखर्च: ₹${"%.2f".format(Locale.US, c)}\nअनुमानित बचत: ₹${"%.2f".format(Locale.US, gross-c)}"
                statusText.text = result.text
            }
            .setNegativeButton("बंद", null).show()
    }

    private fun showAi() {
        dialog("AI किसान साथी", "आप अपना सवाल लिखकर/बोलकर पूछ सकते हैं।\n\nउदाहरण:\n• गेहूँ कब बेचना बेहतर होगा?\n• मेरी फसल का हिसाब बताइए।\n• पास की मंडी कैसे खोजूँ?\n\n⚠️ Live AI/backend connection अभी जोड़ा नहीं गया है; गलत या अनुमानित जानकारी को सरकारी भाव के रूप में नहीं दिखाया जाएगा।")
    }

    private fun dialog(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("ठीक है", null).show()
    }
}
