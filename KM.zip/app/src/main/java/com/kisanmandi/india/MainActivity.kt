package com.kisanmandi.india

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private val green = 0xFF2E7D32.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
        }

        fun title(t: String, size: Float = 26f): TextView =
            TextView(this).apply {
                text = t
                textSize = size
                setPadding(0, 0, 0, 20)
            }

        fun btn(t: String, action: () -> Unit): Button =
            Button(this).apply {
                text = t
                setOnClickListener { action() }
                setPadding(0, 12, 0, 12)
            }

        root.addView(title("🌾 किसान मंडी"))
        root.addView(title("किसानों और खरीदारों के लिए मंडी प्लेटफॉर्म", 16f))

        root.addView(btn("आज का मंडी भाव") { showPrices() })
        root.addView(btn("📍 कहाँ बेचें?") { openNearbyMandis() })
        root.addView(btn("🤝 भरोसेमंद खरीदार") { dialog("भरोसेमंद खरीदार", "यह मॉड्यूल खरीदारों की सत्यापन/सूची के लिए तैयार है।") })
        root.addView(btn("📦 मेरा माल") { dialog("मेरा माल", "अपनी फसल, मात्रा और बिक्री स्थिति जोड़ने का मॉड्यूल।") })
        root.addView(btn("🔐 Login / OTP") { dialog("Login / OTP", "OTP के लिए Firebase/SMS backend credentials जोड़ने पर वास्तविक सत्यापन सक्रिय किया जा सकता है।") })
        root.addView(btn("🤖 AI किसान साथी") { dialog("AI किसान साथी", "भाव, बाजार और बिक्री संबंधी सहायता के लिए AI integration hook तैयार है।") })
        root.addView(btn("🔒 Privacy") { dialog("Privacy", "आपकी जानकारी का उपयोग ऐप की सेवाएँ देने के लिए किया जाएगा।") })

        setContentView(root)
    }

    private fun showPrices() {
        dialog("आज का मंडी भाव", """
            गेहूँ — डेटा सेवा उपलब्ध होने पर लाइव भाव
            धान — डेटा सेवा उपलब्ध होने पर लाइव भाव
            मक्का — डेटा सेवा उपलब्ध होने पर लाइव भाव
            गन्ना/गुड़ — डेटा सेवा उपलब्ध होने पर लाइव भाव

            स्रोत integration: data.gov.in / AGMARKNET
        """.trimIndent())
    }

    private fun openNearbyMandis() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 101)
        }
        val uri = Uri.parse("geo:0,0?q=mandi")
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun dialog(title: String, msg: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
    }
}
