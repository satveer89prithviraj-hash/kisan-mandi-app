# मोबाइल से Cloud Build

1. GitHub पर नया repository बनाएं: `kisan-mandi-app`.
2. इस project की पूरी files upload करें.
3. Branch `main` में commit करें.
4. GitHub के Actions tab में `Kisan Mandi Android Build` खोलें.
5. `Run workflow` दबाएं, अगर push से workflow पहले ही शुरू न हुआ हो.
6. Build पूरा होने पर `kisan-mandi-release-aab` artifact डाउनलोड करें.

यह release AAB unsigned होगा। Play Store production के लिए upload/app signing की अंतिम प्रक्रिया Play Console में करनी होगी। Secrets/API keys को repository में न डालें.
