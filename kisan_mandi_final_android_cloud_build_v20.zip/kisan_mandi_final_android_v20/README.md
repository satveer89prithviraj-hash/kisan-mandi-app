# किसान मंडी — Final Android Cloud Build Project

यह v20 final Android cloud-build project है। v17 के farmer-home flow को compileable Android project में व्यवस्थित किया गया है और GitHub Actions workflow जोड़ा गया है ताकि मोबाइल से cloud runner पर release AAB build किया जा सके।

v18/v19 की security/release policies अलग docs में पहले से तैयार हैं; production API secrets इस project में नहीं हैं.

अभी यह **signed production AAB नहीं** है। पहले cloud build से release AAB बनेगा, फिर signing/Play Console release होगा.
