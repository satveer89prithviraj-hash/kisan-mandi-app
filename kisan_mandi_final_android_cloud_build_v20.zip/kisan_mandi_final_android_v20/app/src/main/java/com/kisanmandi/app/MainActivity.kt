package com.kisanmandi.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var commodity: EditText
    private lateinit var status: TextView
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        commodity = findViewById(R.id.commodityInput)
        status = findViewById(R.id.statusText)
        findViewById<Button>(R.id.voiceButton).setOnClickListener { startHindiVoice() }
        findViewById<Button>(R.id.priceButton).setOnClickListener { safeMessage("आज का भाव: backend से official data आने पर दिखेगा।") }
        findViewById<Button>(R.id.sellButton).setOnClickListener { safeMessage("कहाँ बेचें: location + official price + transport के आधार पर गणना होगी।") }
        findViewById<Button>(R.id.buyerButton).setOnClickListener { safeMessage("केवल verified/active buyer offers दिखेंगे।") }
        findViewById<Button>(R.id.myGoodsButton).setOnClickListener { safeMessage("मेरा माल module अगले backend connection में खुलेगा।") }
        findViewById<Button>(R.id.calculatorButton).setOnClickListener { safeMessage("आज का हिसाब: मात्रा × भाव − खर्च।") }
        findViewById<Button>(R.id.aiButton).setOnClickListener { safeMessage("AI किसान साथी: official price invent नहीं करेगा।") }
    }

    private fun startHindiVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            safeMessage("इस फोन में speech recognition उपलब्ध नहीं है।")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) { commodity.setText(text); status.text = "आपने कहा: $text" }
            }
            override fun onError(error: Int) { status.text = "आवाज़ समझ नहीं आई। फिर से बोलें या टाइप करें।" }
            override fun onReadyForSpeech(params: Bundle?) { status.text = "सुन रहा हूँ…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer?.startListening(intent)
    }

    private fun safeMessage(message: String) {
        status.text = message
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }
}
