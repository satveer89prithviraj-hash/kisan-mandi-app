package com.kisanmandi.india

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(makeHome())
    }

    private fun makeHome(): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 32)
            setBackgroundColor(0xFFF7F9F7.toInt())
        }

        val title = TextView(this).apply {
            text = "🌾 किसान मंडी"
            textSize = 30f
            setTextColor(0xFF174D2B.toInt())
        }
        box.addView(title)

        val sub = TextView(this).apply {
            text = "आज का मंडी भाव • खरीदार • मेरा माल"
            textSize = 16f
            setPadding(0, 10, 0, 28)
        }
        box.addView(sub)

        addButton(box, "📈 आज का भाव") {
            AlertDialog.Builder(this)
                .setTitle("आज का भाव")
                .setMessage("लाइव मंडी भाव के लिए सरकारी data.gov.in / AGMARKNET API जोड़ी जाएगी। अभी demo fallback उपलब्ध है।")
                .setPositiveButton("ठीक है", null).show()
        }

        addButton(box, "📍 कहाँ बेचें?") {
            requestLocation()
            val uri = Uri.parse("geo:0,0?q=APMC+Mandi")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }

        addButton(box, "🤝 भरोसेमंद खरीदार") {
            AlertDialog.Builder(this)
                .setTitle("भरोसेमंद खरीदार")
                .setMessage("KYC/verified buyer सुविधा backend जुड़ने के बाद सक्रिय होगी।")
                .setPositiveButton("ठीक है", null).show()
        }

        addButton(box, "📦 मेरा माल") {
            AlertDialog.Builder(this)
                .setTitle("मेरा माल")
                .setMessage("आपकी फसल, मात्रा और बिक्री रिकॉर्ड सुरक्षित server sync के साथ जोड़े जाएंगे।")
                .setPositiveButton("ठीक है", null).show()
        }

        addButton(box, "🔐 Login / OTP") {
            AlertDialog.Builder(this)
                .setTitle("Login / OTP")
                .setMessage("OTP login के लिए सुरक्षित backend/Firebase phone authentication configuration आवश्यक है।")
                .setPositiveButton("ठीक है", null).show()
        }

        addButton(box, "🤖 AI किसान साथी") {
            AlertDialog.Builder(this)
                .setTitle("AI किसान साथी")
                .setMessage("मंडी भाव, बिक्री समय और खेती से जुड़े सुझाव देने वाला AI backend यहाँ जोड़ा जाएगा।")
                .setPositiveButton("ठीक है", null).show()
        }

        addButton(box, "🔒 Privacy") {
            AlertDialog.Builder(this)
                .setTitle("Privacy")
                .setMessage("Kisan Mandi केवल आवश्यक सुविधाओं के लिए अनुमति मांगता है। आपकी जानकारी बिना अनुमति साझा नहीं की जाएगी।")
                .setPositiveButton("ठीक है", null).show()
        }

        return box
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = TextView(this).apply {
            text = label
            textSize = 18f
            setTextColor(0xFF123B23.toInt())
            setBackgroundColor(0xFFFFFFFF.toInt())
            setPadding(24, 24, 24, 24)
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, 16)
        parent.addView(b, lp)
    }

    private fun requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            locationPermission.launch(
                arrayOf(
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            )
        }
    }
}
