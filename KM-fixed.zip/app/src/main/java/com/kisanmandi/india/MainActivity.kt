package com.kisanmandi.india

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.OtpType
import io.github.jan.supabase.auth.providers.builtin.OTP
import io.github.jan.supabase.createSupabaseClient
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val supabase = createSupabaseClient(
        supabaseUrl = "https://cpzenbcikutsusindxtn.supabase.co",
        supabaseKey = "sb_publishable_cFSAr4AJyxii0HcuBk9bng_IY4yokr9"
    ) {
        install(Auth) {
            autoLoadFromStorage = true
            alwaysAutoRefresh = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
        }

        fun title(t: String, size: Float = 26f): TextView =
            TextView(this).apply {
                text = t
                textSize = size
                setPadding(0, 0, 0, 20)
            }

        fun btn(t: String, action: () -> Unit): Button =
            Button(this).apply {
                text = t
                setOnClickListener { action() }
                setPadding(0, 12, 0, 12)
            }

        root.addView(title("🌾 किसान मंडी"))
        root.addView(title("किसानों और खरीदारों के लिए मंडी प्लेटफॉर्म", 16f))
        root.addView(btn("आज का मंडी भाव") { showPrices() })
        root.addView(btn("📍 कहाँ बेचें?") { openNearbyMandis() })
        root.addView(btn("🤝 भरोसेमंद खरीदार") { dialog("भरोसेमंद खरीदार", "यह मॉड्यूल खरीदारों की सत्यापन/सूची के लिए तैयार है।") })
        root.addView(btn("📦 मेरा माल") { dialog("मेरा माल", "अपनी फसल, मात्रा और बिक्री स्थिति जोड़ने का मॉड्यूल।") })
        root.addView(btn("🔐 Login / OTP") { showLoginDialog() })
        root.addView(btn("🤖 AI किसान साथी") { dialog("AI किसान साथी", "भाव, बाजार और बिक्री संबंधी सहायता के लिए AI integration hook तैयार है।") })
        root.addView(btn("🔒 Privacy") { dialog("Privacy", "आपकी जानकारी का उपयोग ऐप की सेवाएँ देने के लिए किया जाएगा।") })
        setContentView(root)
    }

    private fun showLoginDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 8, 20, 0)
        }
        val phone = EditText(this).apply {
            hint = "मोबाइल नंबर (10 अंक)"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        box.addView(phone)
        AlertDialog.Builder(this)
            .setTitle("किसान मंडी Login / OTP")
            .setMessage("अपने मोबाइल नंबर पर OTP प्राप्त करें।")
            .setView(box)
            .setNegativeButton("रद्द करें", null)
            .setPositiveButton("OTP भेजें", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val raw = phone.text.toString().trim().replace(" ", "")
                        val number = when {
                            raw.matches(Regex("^[6-9]\\d{9}$")) -> "+91$raw"
                            raw.matches(Regex("^\\+91[6-9]\\d{9}$")) -> raw
                            else -> ""
                        }
                        if (number.isEmpty()) {
                            phone.error = "सही 10-अंकीय भारतीय मोबाइल नंबर डालें"
                            return@setOnClickListener
                        }
                        dialog.dismiss()
                        sendOtp(number)
                    }
                }
            }.show()
    }

    private fun sendOtp(phone: String) {
        lifecycleScope.launch {
            try {
                supabase.auth.signInWith(OTP) { this.phone = phone }
                showOtpDialog(phone)
            } catch (e: Exception) {
                dialog("OTP भेजने में समस्या", e.message ?: "कृपया कुछ देर बाद फिर प्रयास करें।")
            }
        }
    }

    private fun showOtpDialog(phone: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 8, 20, 0)
        }
        val otp = EditText(this).apply {
            hint = "6 अंकों का OTP"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            gravity = Gravity.CENTER
        }
        box.addView(otp)
        AlertDialog.Builder(this)
            .setTitle("OTP सत्यापन")
            .setMessage("$phone पर भेजा गया OTP डालें।")
            .setView(box)
            .setNegativeButton("रद्द करें", null)
            .setNeutralButton("OTP दोबारा भेजें", null)
            .setPositiveButton("सत्यापित करें", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                        sendOtp(phone)
                        dialog.dismiss()
                    }
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val token = otp.text.toString().trim()
                        if (!token.matches(Regex("^\\d{6}$"))) {
                            otp.error = "6 अंकों का OTP डालें"
                            return@setOnClickListener
                        }
                        dialog.dismiss()
                        verifyOtp(phone, token)
                    }
                }
            }.show()
    }

    private fun verifyOtp(phone: String, token: String) {
        lifecycleScope.launch {
            try {
                supabase.auth.verifyPhoneOtp(
                    type = OtpType.Phone.SMS,
                    phone = phone,
                    token = token
                )
                dialog("Login सफल", "मोबाइल नंबर सत्यापित हो गया है। अब आप Kisan Mandi की authenticated सुविधाएँ इस्तेमाल कर सकते हैं।")
            } catch (e: Exception) {
                dialog("OTP सत्यापन विफल", e.message ?: "OTP गलत या समाप्त हो चुका है।")
            }
        }
    }

    private fun showPrices() {
        dialog("आज का मंडी भाव", """
            गेहूँ — डेटा सेवा उपलब्ध होने पर लाइव भाव
            धान — डेटा सेवा उपलब्ध होने पर लाइव भाव
            मक्का — डेटा सेवा उपलब्ध होने पर लाइव भाव
            गन्ना/गुड़ — डेटा सेवा उपलब्ध होने पर लाइव भाव

            स्रोत integration: data.gov.in / AGMARKNET
        """.trimIndent())
    }

    private fun openNearbyMandis() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 101)
        }
        val uri = Uri.parse("geo:0,0?q=mandi")
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun dialog(title: String, msg: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
    }
}
