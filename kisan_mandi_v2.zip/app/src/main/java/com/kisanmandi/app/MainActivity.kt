package com.kisanmandi.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.gson.Gson
import com.google.gson.JsonObject
import okhttp3.*
import java.io.IOException
import java.util.Locale
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    private val http = OkHttpClient()
    private val gson = Gson()
    private val locationClient by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private lateinit var commodity: EditText
    private lateinit var status: TextView

    // Put the data.gov.in key in app settings later. Never publish a real secret in source control.
    private val dataGovKey = "PASTE_DATA_GOV_IN_API_KEY_HERE"
    private val dataGovResource = "9ef84268-d588-465a-a308-a864a43d0070"

    private val demo = listOf(
        "गेहूँ — मंडी उदाहरण: ₹2,200–₹2,450 | मॉडल ₹2,325",
        "धान — मंडी उदाहरण: ₹1,900–₹2,350 | मॉडल ₹2,150",
        "आलू — मंडी उदाहरण: ₹900–₹1,450 | मॉडल ₹1,180",
        "प्याज — मंडी उदाहरण: ₹1,200–₹2,200 | मॉडल ₹1,700"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        commodity = findViewById(R.id.commodityInput)
        status = findViewById(R.id.statusText)

        findViewById<Button>(R.id.priceButton).setOnClickListener { loadPrices() }
        findViewById<Button>(R.id.nearbyButton).setOnClickListener { findNearbyMandis() }
        findViewById<Button>(R.id.sellButton).setOnClickListener { sellWhere() }
        findViewById<Button>(R.id.buyerButton).setOnClickListener { buyers() }
        findViewById<Button>(R.id.myGoodsButton).setOnClickListener { myGoods() }
        findViewById<Button>(R.id.accountButton).setOnClickListener { login() }
        findViewById<Button>(R.id.aiButton).setOnClickListener { aiAssistant() }
        findViewById<Button>(R.id.privacyButton).setOnClickListener { privacy() }
    }

    private fun loadPrices() {
        val crop = commodity.text.toString().trim()
        if (crop.isEmpty()) { commodity.error = "फसल लिखें"; return }
        if (dataGovKey.startsWith("PASTE_")) {
            status.text = "डेमो भाव (live API key अभी नहीं जोड़ी गई):\n\n" +
                    demo.filter { it.startsWith(crop.take(2)) || crop.contains("गेह") && it.startsWith("गेह") ||
                    crop.contains("धान") && it.startsWith("धान") ||
                    crop.contains("आलू") && it.startsWith("आलू") ||
                    crop.contains("प्याज") && it.startsWith("प्याज") }.ifEmpty { demo }.joinToString("\n")
            return
        }
        status.text = "सरकारी डेटा से भाव लाया जा रहा है…"
        val url = "https://api.data.gov.in/resource/$dataGovResource?api-key=$dataGovKey&format=json&limit=20&filters[commodity]=${
            Uri.encode(crop)
        }"
        http.newCall(Request.Builder().url(url).get().build()).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { status.text = "Live data नहीं मिला। इंटरनेट/API key जाँचें।\n${e.message}" }
            }
            override fun onResponse(call: Call, response: Response) {
                val text = response.body?.string().orEmpty()
                runOnUiThread {
                    if (!response.isSuccessful) { status.text = "सरकारी API error: ${response.code}"; return@runOnUiThread }
                    try {
                        val obj = gson.fromJson(text, JsonObject::class.java)
                        val records = obj.getAsJsonArray("records")
                        if (records == null || records.size() == 0) {
                            status.text = "इस फसल के लिए रिकॉर्ड नहीं मिला।"
                        } else {
                            val out = StringBuilder("सरकारी मंडी डेटा:\n\n")
                            records.forEach { r ->
                                val o = r.asJsonObject
                                out.append("${o.get("market")?.asString ?: "-"} | ")
                                    .append("${o.get("district")?.asString ?: "-"} | ")
                                    .append("₹${o.get("min_price")?.asString ?: "-"}–₹${o.get("max_price")?.asString ?: "-"}")
                                    .append(" | मॉडल ₹${o.get("modal_price")?.asString ?: "-"}\n")
                            }
                            status.text = out.toString()
                        }
                    } catch (e: Exception) { status.text = "डेटा पढ़ने में समस्या: ${e.message}" }
                }
            }
        })
    }

    private fun findNearbyMandis() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 10)
            status.text = "पास की मंडियों के लिए Location permission दें।"
            return
        }
        locationClient.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
            .addOnSuccessListener { loc ->
                if (loc == null) { status.text = "Location नहीं मिल सकी।"; return@addOnSuccessListener }
                status.text = "आपकी location मिली।\nLatitude: %.5f\nLongitude: %.5f\n\nनजदीकी मंडी खोजने के लिए नीचे Maps खोलें.".format(Locale.US, loc.latitude, loc.longitude)
                val uri = Uri.parse("geo:${loc.latitude},${loc.longitude}?q=APMC%20Mandi")
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
            .addOnFailureListener { status.text = "Location error: ${it.message}" }
    }

    private fun sellWhere() {
        val crop = commodity.text.toString().ifBlank { "फसल" }
        val uri = Uri.parse("geo:0,0?q=${Uri.encode("APMC mandi $crop")}")
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun buyers() = show("भरोसेमंद खरीदार", "Buyer module तैयार है: buyer registration, KYC status और offer records के लिए Firebase backend जोड़ना बाकी है। बिना verification किसी buyer को verified नहीं दिखाया जाएगा।")
    private fun myGoods() = show("मेरा माल", "यहाँ किसान अपनी फसल, मात्रा, अपेक्षित भाव और बिक्री स्थिति रख सकेगा। Firebase/Firestore जोड़ने पर यह डेटा server पर सुरक्षित रूप से sync होगा।")
    private fun login() = show("Login / OTP", "Firebase Phone OTP integration के लिए Firebase project + google-services.json + SHA-256 + Phone Sign-in enable करना होगा। यह सुरक्षा कारणों से APK में secret डालकर पूरा नहीं किया जाता।")
    private fun aiAssistant() = show("AI किसान साथी", "AI backend का सुरक्षित hook तैयार किया गया है। Production में API key server पर रखी जाएगी, APK में नहीं।")
    private fun privacy() {
        show("Privacy Policy", "किसान मंडी location, phone/login और app data जैसी जानकारी का उपयोग केवल संबंधित सुविधा के लिए करेगा। Production release से पहले final privacy policy और Data Safety declaration भरना आवश्यक है।")
    }
    private fun show(title: String, msg: String) = AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("ठीक है", null).show()
}
