# Kisan Mandi V2 — अंतिम बाहरी कनेक्शन

यह ZIP एक मजबूत V2 codebase है। Android build के लिए कोई secret आवश्यक नहीं है; external services केवल उनके account/configuration के बाद live होंगी।

## 1. Live Mandi Bhav
Official source: data.gov.in / DMI / AGMARKNET.
- Data.gov.in API key लें.
- `MainActivity.kt` में `dataGovKey` को अपनी key से बदलें.
- Resource endpoint को जरूरत अनुसार official resource page से verify करें.
- असली secret को public GitHub में commit न करें; production में server-side proxy बेहतर है.

## 2. Location / Nearby Mandi
- Android runtime location permission मांगी जाती है.
- Google Maps app उपलब्ध होने पर APMC/mandi search खुलती है.
- Maps SDK key की जरूरत नहीं क्योंकि navigation/search intent इस्तेमाल किया गया है.

## 3. Firebase Login / OTP + Database
Firebase console में:
- Android app package: `com.kisanmandi.app`
- SHA-256 जोड़ें.
- Authentication > Sign-in method > Phone enable करें.
- SMS region policy में India allow करें.
- Firestore Database बनाएं.
- `google-services.json` डाउनलोड करके `app/` में रखें.
- फिर Google services plugin enable करें.
Phone OTP में SMS verification और app verification दोनों आवश्यक हैं.

## 4. Verified Buyers
Firestore collections सुझाई गईं:
- users
- buyer_profiles
- buyer_documents
- buyer_offers
- farmer_goods
- sales
केवल admin-approved KYC status वाले buyer को "Verified" दिखाएँ.

## 5. AI किसान साथी
AI provider key APK में न रखें. एक छोटा HTTPS backend endpoint बनाएं:
POST /ai/ask
body: {"question":"...","crop":"...","language":"hi"}
Backend provider key रखे और response app को दे.

## 6. Ads / Earning
AdMob में app register करके App ID लें. Development में केवल test ads चलाएँ. Production से पहले consent/privacy/Data Safety configuration पूरा करें.

## 7. Play Store
Required:
- Privacy Policy URL
- App icon / feature graphic / screenshots
- Data Safety form
- Content rating
- Target audience
- App access/login instructions if needed
- Closed testing and other Play Console requirements applicable to the developer account.

## 8. Important
Current build intentionally falls back to demo prices when no API key is configured. It does NOT falsely claim demo values are live government prices.
