# किसान मंडी — Privacy Policy Draft

किसान मंडी उपयोगकर्ता की गोपनीयता का सम्मान करता है। ऐप में उपयोग की जाने वाली जानकारी सुविधा के अनुसार सीमित रखी जानी चाहिए।

### Location
Nearby mandi सुविधा के लिए location permission मांगी जा सकती है। उपयोगकर्ता permission न देने पर location आधारित सुविधा उपलब्ध नहीं होगी।

### Phone / OTP
यदि Firebase Phone Authentication सक्षम किया जाता है, तो phone number SMS OTP verification के लिए उपयोग होगा। Firebase की सेवा शर्तों और privacy disclosures लागू होंगे।

### Farmer / Buyer data
नाम, फसल, मात्रा, offers या profile information केवल account/backend सुविधा के लिए संग्रहित की जाएगी। Verified buyer का दावा केवल administrator/KYC verification के बाद किया जाना चाहिए।

### Data security
Production में API keys और AI provider secrets APK में नहीं रखे जाएंगे। Backend/server-side secrets का उपयोग किया जाएगा।

### Third parties
Data.gov.in/AGMARKNET, Firebase, Google Maps/Google Play services, और यदि सक्षम हो तो AdMob जैसी सेवाएँ अपनी-अपनी नीतियों के अनुसार डेटा process कर सकती हैं।

### Contact
Play Store publication से पहले यहाँ वास्तविक support email और legal entity/contact details भरें.

यह एक publication draft है; final policy को आपके वास्तविक backend, ads, analytics और data flows के अनुसार अपडेट करना आवश्यक है।
