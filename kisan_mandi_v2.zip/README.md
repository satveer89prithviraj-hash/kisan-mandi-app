# Kisan Mandi V2

Version 2.0.0 — functional Android foundation for the production features requested:
- live mandi price integration hook
- location / nearby mandi
- sell-where Maps flow
- farmer goods module foundation
- verified buyer/KYC module foundation
- Firebase OTP/database integration layer
- AI backend hook
- privacy, Play Store listing and testing drafts

The app deliberately does not fake live prices or verified buyers. External credentials/configuration are required for production services.
