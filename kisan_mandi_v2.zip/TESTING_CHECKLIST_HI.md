# Kisan Mandi V2 — Testing Checklist

1. Fresh install / update install.
2. Hindi UI और Android 13/14/15/16 device checks.
3. Location permission allow / deny दोनों cases.
4. GPS off case.
5. Internet off case.
6. Live API key absent → demo fallback.
7. API error → clear error message.
8. Crop search with Hindi text.
9. Google Maps intent.
10. OTP: valid/invalid/timeout/resend.
11. Firestore: farmer goods save/read/update/delete with security rules.
12. Buyer KYC pending/approved/rejected.
13. Unverified buyer must never show as verified.
14. AI backend timeout/error and rate limiting.
15. AdMob test ads only during development.
16. Privacy policy URL accessible.
17. Data Safety answers match actual collected/shared data.
18. Play Console closed testing requirements for this account.
19. Release AAB signed by Play App Signing / correct upload key.
20. Crash-free smoke test before production.

## Release rule
Live prices, verified buyers, OTP, AI and ads should not be presented as active until their external services are actually configured and tested.
