# Kisan Mandi — Complete Cloud Build Package

Package name: `com.kisanmandi.india`

This package contains the Android project and a single GitHub Actions workflow for a signed Release AAB.

IMPORTANT:
- The private keystore is NOT included in this ZIP and must never be committed to a public repository.
- The workflow uses the existing GitHub repository secret `KISAN_KEYSTORE_B64`.
- It also requires the repository secret `KISAN_KEYSTORE_PASSWORD`.
- Key alias is `kisanmandi`.
- The app is prepared for data.gov.in/AGMARKNET, location, buyers, goods, OTP and AI integration. Live external services require their own credentials/backend configuration.
